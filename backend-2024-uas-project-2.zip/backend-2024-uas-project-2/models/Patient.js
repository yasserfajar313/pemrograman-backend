// import database

// membuat class Patient
class Patient {
  // buat fungsi
}

// export class Patient
module.exports = Patient;
