// import Model Patient

// buat class PatientController
class PatientController {
  // buat fungsi
}

// membuat object PatientController
const object = new PatientController();

// export object PatientController
module.exports = object;
