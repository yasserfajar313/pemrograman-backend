# Final Project UAS

Building Covid RESTful API using Express.js

## Install dan Jalankan Aplikasi

Install aplikasi dan dependencies (cukup jalankan sekali):

```bash
npm install
```

Jalankan aplikasi:

```bash
npm run start
```
